﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day7
{
    class Program3
    {
        static void Main(string[] args)
        {
            int i, n;
            float classavg = 0f;
            Console.WriteLine("Enter num of records = ");
            n = int.Parse(Console.ReadLine());

            Student[] ob = new Student[n];
            for (i = 0; i < n; i++)
            {
                ob[i] = new Student();
                ob[i].getdata();
                classavg += ob[i].avg;
            }
            classavg = classavg / n;
            Console.WriteLine("\nclass average = {0}\n\n",classavg);

            Console.WriteLine("Enter the student name (search key)");
            string name = Console.ReadLine();
            int flag = 0;
            for(i=0;i<n;i++)
            {
                if(name==ob[i].name)
                {
                    ob[i].display();
                    flag = 1;
                }
            }
            if(flag==0)
                Console.WriteLine("Student record doesnt exist");

        }
    }
}

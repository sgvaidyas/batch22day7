﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day7
{
    class Student
    {
        //data members
        public int roll, age, classnum;
        public string name;
        public float[] marks;
        public float   total, avg;

        //member function
        public void getdata()
        {
            Console.Write("Enter roll number  =  ");
             roll = int.Parse(Console.ReadLine());
               Console.Write("Enter age  =  ");
               age = int.Parse(Console.ReadLine());
            Console.Write("Enter class are you studying in  =  ");
            classnum = int.Parse(Console.ReadLine());
            Console.Write("Enter name  =  ");
            name =Console.ReadLine();
            Console.Write("Enter the num of subjects     = ");
            int n = int.Parse(Console.ReadLine());
            marks = new float[n];
            total = 0f;
            for(int i=0;i<n;i++)
            {
                Console.Write("Enter the Subject:{0} marks  = ",i+1);
                marks[i] = float.Parse(Console.ReadLine());
                total= total + marks[i];
            }
            avg = total / n;
        }

        public void display()
        {
            Console.WriteLine("______________________________");

            Console.WriteLine("ROLL NUMBER     = " + roll);
            Console.WriteLine("NAME            = "+ name);
            Console.WriteLine("CLASS           = " + classnum);
            Console.WriteLine("AGE             = " + age);
            for(int i =0;i<marks.Length;i++)
                Console.WriteLine("MARKS [{0}]        = {1}" ,i+1,marks[i] );
            Console.WriteLine("TOTAL           = " + total);
            Console.WriteLine("AVERAGE         = " + avg);

        }
    }
}

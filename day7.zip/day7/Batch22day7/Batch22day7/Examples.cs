﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day7
{
    class Examples
    {
        static bool isrepeated(int[] unique, int num,int i)
        {
            for (int j = 0; j < i; j++)
            {
                if (num == unique[j])
                    return true;
            }
            return false;
        }
        static void Main(string[] args)
        {
            int num,i=0,j;
            int[] unique = new int[100];
            do
            {
                Console.WriteLine("Enter number (to go out of loop press 999) =");
                num = int.Parse(Console.ReadLine());
                
                if (isrepeated(unique,num,i) ==false)
                {
                    unique[i] = num;
                    i++;
                }
            } while (num!=999);
            int n = i - 1;
            Console.WriteLine("Num of elements in array = "+n);

            for(i=0;i<n;i++)
                Console.WriteLine(unique[i]);
        }
    }
}

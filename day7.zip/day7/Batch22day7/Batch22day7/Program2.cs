﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day7
{
    class Program2
    {
        static void Main(string[] args)
        {
            int i, n;
            Console.WriteLine("Enter num of records = ");
            n = int.Parse(Console.ReadLine());

            Student[] ob = new Student[n];
            for (i = 0; i < n; i++)
            {
                ob[i] = new Student();
                ob[i].getdata();
            }
            for (i = 0; i < n; i++)
            {
                ob[i].display();
            }
        }
    }
}

﻿using System;

namespace Batch22day7
{
    class ClassArray
    {
        public int[] a;
        public int ind,max;

        public ClassArray()
        {
            Console.WriteLine("Enter n value");
            max = int.Parse(Console.ReadLine());

            a = new int[max];
            ind = -1;
        }
        public void insert(int val)
        {
            if(ind<max-1)
            {
                int pos = 0;
                //finding the position to insert
                for (int i = 0; i <= ind; i++)
                {
                    if (val < a[i])
                    {
                        pos = i;
                        break;
                    }
                }
                //right shift from given position to the end of the array
                for (int j = ind; j >= pos; j--)
                {
                    a[j + 1] = a[j];
                }
                a[pos] = val;
                ind++;
            }
            else
                Console.WriteLine("Array overflow");
                
        }
        public void display()
        {
            Console.WriteLine("Array elements are ");
            for(int i=0;i<=ind;i++)
                Console.Write(a[i] + "\t");
            Console.WriteLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day7
{
    class Program5
    {
        static void Main(string[] args)
        {
            ClassArray ob = new ClassArray();
            int x, ch;
            do
            {
                Console.WriteLine("Enter a value ");
                x = int.Parse(Console.ReadLine());
                ob.insert(x);
                ob.display();

                Console.WriteLine("If you want to continue press 1");
                ch = int.Parse(Console.ReadLine());
            } while (ch==1);
            
        }
    }
}

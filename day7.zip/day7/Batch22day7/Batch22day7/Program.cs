﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day7
{
    class Program
    {
        static void Main(string[] args)
        {
            Student ob = new Student();
            ob.getdata();
            ob.display();
        }
    }
}

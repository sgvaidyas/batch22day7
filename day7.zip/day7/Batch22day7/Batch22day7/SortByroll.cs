﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22day7
{
    class SortByroll
    {
        static void Main(string[] args)
        {
            int i,j, n;

            Console.WriteLine("Enter num of records = ");
            n = int.Parse(Console.ReadLine());


            Student[] ob = new Student[n];
            for (i = 0; i < n; i++)
            {
                ob[i] = new Student();
                ob[i].getdata();
            }

            //Bubble sort logic
            Student temp;

            for(i=0;i<n-1;i++)
            {
                for(j=0;j<n-i-1;j++)
                {
                    if(ob[j].roll > ob[j+1].roll)
                    {
                        temp = ob[j];
                        ob[j] = ob[j + 1];
                        ob[j + 1] = temp;
                    }
                }
            }
            //sorted objects 
            for (i = 0; i < n; i++)
                ob[i].display();



        }
    }
}

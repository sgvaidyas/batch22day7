﻿using System;

namespace Batch22day7
{
    class Program4
    {
        static bool isrepeated(int[] unique, int num, int ind)
        {
            for (int j = 0; j < ind; j++)
            {
                if (num == unique[j])
                    return true;
            }
            return false;
        }
        static void Main(string[] args)
        {
            int i, n,ind=0;
            float classavg = 0f;
            
            Console.WriteLine("Enter num of records = ");
            n = int.Parse(Console.ReadLine());

            int[] classarray = new int[n];

            Student[] ob = new Student[n];
            for (i = 0; i < n; i++)
            {
                ob[i] = new Student();
                ob[i].getdata();

                if(isrepeated(classarray,ob[i].classnum,ind) == false)
                {
                    classarray[ind] = ob[i].classnum;
                    ind++;
                }
            }
            Console.WriteLine("\n\n class numbers");
            int count;
            float sumofavg,avg;
            for (i=0;i<ind;i++)
            {
                count = 0;
                sumofavg = 0f;
                for (int j=0;j<n;j++)
                {                    
                    if(classarray[i] == ob[j].classnum)
                    {
                        sumofavg += ob[j].avg;
                        count++;
                    }
                }
                avg = sumofavg / count;
                Console.WriteLine("Average of class{0} = {1} " ,classarray[i], avg );
            }
        }
    }
}
